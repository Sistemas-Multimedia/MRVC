# Generate a prediction ideltical to the previous subband.

def generate_prediction(AL, BL, CL, AH, CH):
    return CH

