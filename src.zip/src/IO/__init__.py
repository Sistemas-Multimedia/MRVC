if __debug__:
    print("io/__init__.py loaded")
