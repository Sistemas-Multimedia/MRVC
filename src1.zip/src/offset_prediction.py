# Designed for testing purposes, The result from MCDWT should the the
# same that MDWT.

import numpy as np

def generate_prediction(AL, BL, CL, AH, CH):
    x = np.zeros(AL.shape, np.float64)
    return x-10000
