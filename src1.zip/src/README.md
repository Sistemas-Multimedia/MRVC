# MCDWT/src

Source (program) files.

* DWT.py: An implementation of the color DWT.
* IO: Input/Output of images and pyramids.
* MCDWT.py: An implementation of the MCDWT.
* MDWT.py: An implementation of the MDWT.
* tests: Some useful tests of the used libraries.
